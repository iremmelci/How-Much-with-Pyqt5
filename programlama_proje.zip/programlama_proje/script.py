import pyrebase

config = {
  "apiKey": "AIzaSyCEQdvrVq9igN8YtLiTDTJsD2T4VRYf-B",
  "authDomain": "programlamaproje-76aa2.firebaseapp.com",
  "databaseURL": "https://programlamaproje-76aa2.firebaseio.com",
  "storageBucket": "programlamaproje-76aa2.appspot.com"
}

firebase = pyrebase.initialize_app(config)
db = firebase.database()
print(db)